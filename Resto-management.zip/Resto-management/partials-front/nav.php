<html>
    <section class="navbar">
        <div class="container">
            <div class="logo">
                <a href="#" title="Logo">
                    <img src="images/logo.png" alt="Restaurant Logo" class="img-responsive">
                </a>
            </div>
            <ul class="nav justify-content-end">
                <li class="nav-item">
                  <a class="nav-link "  href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin/login.php">Admin</a>
                  </li>
                <li class="nav-item">
                  <a class="nav-link" href="categories.php">Categories</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="foods.php">Food</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="contact.php">Contact</a>
                </li>
              </ul>
        </div>
    </section>
</html>