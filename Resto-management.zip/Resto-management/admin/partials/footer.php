<div class="footer"  style="background-color: rgb(255, 102, 102);color: white;">
             <div class="wrapper" style="border: 1px solid black;width: 100%; margin: 0 auto;">
                <p class="text-center" style="text-align:center">2023 All rights reserved </p>
                
             </div>

        </div>
    </body>
</html>